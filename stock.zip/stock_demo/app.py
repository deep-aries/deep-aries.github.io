import random
import os
import math
import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st
import yfinance as yf
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from matplotlib.dates import DateFormatter, date2num, num2date
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
from collections import Counter
import io

# Set base directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Credential file for Google Sheets API
CREDENTIALS_PATH = "/home/ec2-user/stock_demo/credentials/deep_chronos_google_api.json"

print("Current directory:", os.getcwd())

# Streamlit page configuration
st.set_page_config(page_title="Our Paper Demo: DeepAries", layout="wide")

# =============================================================================
# Sidebar: FAQ / Help
# =============================================================================
with st.sidebar:
    with st.expander("FAQ / Help"):
        st.markdown("""
        **Q: What does the recommended holding period mean?**  
        A: It is the number of days the model suggests holding the current portfolio allocation before considering rebalancing.

        **Q: How are the portfolio metrics calculated?**  
        A: The demo calculates metrics such as CAGR, Sharpe Ratio (assuming a risk-free rate of 0), annualized volatility, maximum drawdown, and average daily return over the selected test period.

        **Q: Why normalize both portfolio and index?**  
        A: Both the portfolio and the market index are normalized (i.e. their cumulative returns are computed by dividing by the first value in the selected period) to provide an apples‑to‑apples comparison of performance over time.

        **Q: What do the Aggregated Insights show?**  
        A: They summarize rebalancing behavior (total events, average holding period, distribution of holding periods, and the most frequent rebalancing period) along with the most frequently selected stocks.
        """)

# =============================================================================
# Homepage Overview, Paper Information, & Detailed Usage Instructions
# =============================================================================
st.markdown("""
    <style>
        .intro-container {
            background-color: #fdfdfd;
            border-radius: 10px;
            padding: 30px;
            margin-bottom: 30px;
            border: 2px solid #e0e0e0;
            box-shadow: 2px 2px 10px rgba(0,0,0,0.1);
        }
        .intro-container h2 {
            color: #333;
            font-weight: bold;
        }
        .intro-container h3 {
            color: #555;
            margin-top: 20px;
        }
        .intro-container p, .intro-container li {
            font-size: 16px;
            line-height: 1.8;
            color: #444;
        }
        .highlight-banner {
            background-color: #e0f7fa;
            border-left: 5px solid #00acc1;
            padding: 10px;
            margin: 15px 0;
        }
        .paper-info {
            background-color: #fff9c4;
            border-radius: 5px;
            padding: 15px;
            margin: 15px 0;
            border: 1px solid #fdd835;
        }
    </style>
    <div class="intro-container">
        <h2>Welcome to Our Paper Demo: DeepAries 😊</h2>
        <div class="paper-info">
            <h3>Paper Information</h3>
            <p><strong>Title:</strong> DeepAries: Adaptive Rebalancing Interval Selection for Enhanced Portfolio Selection</p>
            <p><strong>Authors:</strong> Jinkyu Kim, Hyunjung Yi, Mogan Gim, Donghee Choi, Jaewoo Kang</p>
            <p><strong>Demo Info:</strong> In this interactive demo, we showcase DeepAries—our novel reinforcement learning framework that dynamically adjusts rebalancing intervals based on market conditions. Evaluation begins on January 1, 2021, and data is continuously updated. The demo provides recommended portfolio allocation, performance comparisons (with both portfolio and benchmark index cumulative returns normalized over the selected period), adaptive rebalancing visualizations, and aggregated insights into rebalancing behavior. Detailed performance summaries are displayed below the main chart for easy comparison between your portfolio and the benchmark index.</p>
            <p><strong>Keywords:</strong> Portfolio Management; Adaptive Rebalancing Interval Selection; Artificial Intelligence in Finance; Deep Reinforcement Learning</p>
        </div>
        <p>
            This interactive demo showcases the model from our paper and lets you explore portfolio recommendations, performance comparisons, and market data—all integrated in one user-friendly dashboard.
        </p>
        <h3>Main Features</h3>
        <ul>
            <li>
                <strong>Paper Information:</strong> Essential details about the paper and its methodology are provided to confirm the academic basis.
            </li>
            <li>
                <strong>User Input Panel:</strong> Select a portfolio model (e.g., Transformer, Reformer, etc.), target market (e.g., DJ 30, KOSPI, CSI 300, FTSE), and a test period. (Data is evaluated from January 1, 2021 onward and is continuously updated.)
            </li>
            <li>
                <strong>Stacked Bar Chart Tab:</strong>
                <ul>
                    <li>
                        <em>Recommended Portfolio Allocation:</em> A pie chart illustrates the allocation based on the most recent rebalancing event (from your selected end date), showing the Top 5 stocks and an "Others" category.
                    </li>
                    <li>
                        <em>Portfolio Value & Market Index Comparison:</em> A line chart shows the cumulative returns of both the portfolio and the market index—both normalized to 1 at the start of the selected period—for an apples‑to‑apples performance comparison.
                    </li>
                    <li>
                        <em>Adaptive Rebalancing Results:</em> Stacked bar charts display, in chronological order, the portfolio allocation for the Top 5 stocks at each rebalancing event.
                        <br>
                        👉 <strong>Navigation:</strong> If the dataset is extensive, only up to 3 charts are shown per page. Use the page selector to view additional events.
                        <br>💼 This visualization shows when the model rebalanced and how the Top 5 stock ratios evolved.
                    </li>
                    <li>
                        <em>Aggregated Insights:</em> Aggregated metrics and visualizations provide detailed insights into rebalancing behavior, including total events, average holding period, distribution of holding periods, and the most frequent rebalancing period.
                    </li>
                </ul>
            </li>
            <li>
                <strong>Ranked View Tab:</strong> A detailed breakdown of the latest rebalancing event is shown, including individual asset weights.
                <br>
                <em>Note:</em> The model selects 20 promising stocks from the market. The full 20-stock allocation is detailed in this view.
            </li>
            <li>
                <strong>Market Preview Tab:</strong> Explore historical and current market data for selected tickers with interactive charts and downloadable CSV files.
            </li>
        </ul>
        <p>
            <strong>Usage Instructions:</strong><br>
            1. Use the left panel to select a model, market, and test period.<br>
            2. Navigate through the tabs to view portfolio allocation, performance comparisons, detailed asset weights, and market data.<br>
            3. In the Stacked Bar Chart tab, review the rebalancing events and aggregated insights that guide you on when to rebalance and which stocks to consider buying. (Top 5 ratios are shown here, while the full 20-stock breakdown is in Ranked View.)<br>
            4. Enjoy exploring our demo and gaining valuable insights from the proposed strategy!
        </p>
        <div class="highlight-banner">
            <strong>Key Insight:</strong> Based on your selected end date, the model dynamically recommends the next optimal rebalancing day to maximize portfolio performance.
        </div>
    </div>
""", unsafe_allow_html=True)

# =============================================================================
# Google Sheets API Authentication and Data Loading
# =============================================================================
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name(CREDENTIALS_PATH, scope)
client = gspread.authorize(creds)
SPREADSHEET_URL = "https://docs.google.com/spreadsheets/d/1bRkd6crVHwwZes4bGBT1CzxOVGBo9C38g9aOwiZM5mE/edit#gid=0"
spreadsheet = client.open_by_url(SPREADSHEET_URL)


def load_google_sheet(sheet_name):
    """Retrieve data from the specified Google Sheet."""
    try:
        worksheet = spreadsheet.worksheet(sheet_name)
        data = worksheet.get_all_records()
        df = pd.DataFrame(data)
        return df
    except Exception as e:
        st.error(f"Failed to load {sheet_name} from Google Sheets: {e}")
        return pd.DataFrame()


# =============================================================================
# Data Loading
# =============================================================================
index_data = load_google_sheet("test")
if not index_data.empty:
    index_data["date"] = pd.to_datetime(index_data["date"])

marketdata = load_google_sheet("market")
marketdata["date"] = pd.to_datetime(marketdata["date"])
data = load_google_sheet("result")
data["date"] = pd.to_datetime(data["date"])
future_prices = load_google_sheet("market_past")
future_prices["date"] = pd.to_datetime(future_prices["date"])
current_date = datetime.today().date()

# =============================================================================
# User Input Section: Model, Market, and Test Period Selection
# =============================================================================
col1, col2 = st.columns(2)
with col1:
    model_options = data["model"].unique().tolist()
    default_model = "itransformer"
    default_model_index = model_options.index(default_model) if default_model in model_options else 0
    selected_model = st.selectbox("Select Model", model_options, index=default_model_index)

    market_options = data["market"].unique().tolist()
    default_market = "ftse"
    default_market_index = market_options.index(default_market) if default_market in market_options else 0
    selected_market = st.selectbox("Select Market", market_options, index=default_market_index)
with col2:
    start_date = st.date_input("Test Data: Start Date", value=pd.Timestamp("2021-01-01"))
    end_date = st.date_input("Test Data: End Date", value=pd.Timestamp.today())

# =============================================================================
# Data Preprocessing: Filter Data Based on User Selection
# =============================================================================
model_data_dict = {}
model_selected_data = data[
    (data["market"] == selected_market) &
    (data["model"] == selected_model) &
    (data["date"] >= pd.to_datetime(start_date)) &
    (data["date"] <= pd.to_datetime(end_date))
    ].copy()

if not model_selected_data.empty:
    model_data_dict[selected_model] = {"selected_data": model_selected_data}

if selected_model in model_data_dict and not model_data_dict[selected_model]["selected_data"].empty:
    last_available_date = model_data_dict[selected_model]["selected_data"]['date'].max().date()
else:
    last_available_date = "N/A"


# =============================================================================
# Portfolio & Index Summary (Displayed Below Performance Chart)
# =============================================================================
def display_summary():
    df_summary = model_data_dict[selected_model]["selected_data"].sort_values("date")
    if not df_summary.empty:
        # Portfolio Metrics
        start_val = df_summary['Final Portfolio Value'].iloc[0]
        end_val = df_summary['Final Portfolio Value'].iloc[-1]
        pct_change = (end_val - start_val) / start_val * 100
        daily_returns = df_summary['Final Portfolio Value'].pct_change().dropna()
        volatility = daily_returns.std() * (252 ** 0.5) * 100
        running_max = df_summary['Final Portfolio Value'].cummax()
        drawdown = (df_summary['Final Portfolio Value'] / running_max - 1).min() * 100
        avg_daily_return = daily_returns.mean() * 100
        trading_days = (df_summary['date'].iloc[-1] - df_summary['date'].iloc[0]).days
        cagr = (end_val / start_val) ** (365 / trading_days) - 1 if trading_days > 0 else 0
        sharpe_ratio = daily_returns.mean() / daily_returns.std() * (252 ** 0.5) if daily_returns.std() != 0 else 0

        # Index Metrics: filter index data by market and selected period
        filtered_index = index_data[
            (index_data["market"].str.lower() == selected_market.lower()) &
            (index_data["date"] >= pd.to_datetime(start_date)) &
            (index_data["date"] <= pd.to_datetime(end_date))
            ].sort_values("date")
        if not filtered_index.empty:
            idx_start = filtered_index["close"].iloc[0]
            idx_end = filtered_index["close"].iloc[-1]
            idx_pct_change = (idx_end - idx_start) / idx_start * 100
            daily_returns_idx = filtered_index["close"].pct_change().dropna()
            idx_volatility = daily_returns_idx.std() * (252 ** 0.5) * 100
            idx_running_max = filtered_index["close"].cummax()
            idx_drawdown = (filtered_index["close"] / idx_running_max - 1).min() * 100
            idx_avg_daily_return = daily_returns_idx.mean() * 100
            idx_trading_days = (filtered_index["date"].iloc[-1] - filtered_index["date"].iloc[0]).days
            idx_cagr = (idx_end / idx_start) ** (365 / idx_trading_days) - 1 if idx_trading_days > 0 else 0
            idx_sharpe = daily_returns_idx.mean() / daily_returns_idx.std() * (
                        252 ** 0.5) if daily_returns_idx.std() != 0 else 0
        else:
            idx_start = idx_end = idx_pct_change = idx_volatility = idx_drawdown = idx_avg_daily_return = idx_cagr = idx_sharpe = None

        st.markdown("### Performance Summary")
        col_portfolio, col_index = st.columns(2)
        with col_portfolio:
            st.markdown("#### Portfolio Summary")
            st.markdown(f"**Start Value:** {start_val:,.2f}")
            st.markdown(f"**Portfolio Value:** {end_val:,.2f} (Change: {pct_change:.2f}%)")
            st.markdown(f"**Average Daily Return:** {avg_daily_return:.2f}%")
            st.markdown(f"**Annualized Volatility:** {volatility:.2f}%")
            st.markdown(f"**CAGR:** {cagr * 100:.2f}%")
            st.markdown(f"**Sharpe Ratio:** {sharpe_ratio:.2f}")
            st.markdown(f"**Maximum Drawdown:** {drawdown:.2f}%")
        with col_index:
            if idx_start is not None:
                st.markdown("#### Index Summary")
                st.markdown(f"**Start Value (Index):** {idx_start:,.2f}")
                st.markdown(f"**End Value (Index):** {idx_end:,.2f} (Change: {idx_pct_change:.2f}%)")
                st.markdown(f"**Average Daily Return (Index):** {idx_avg_daily_return:.2f}%")
                st.markdown(f"**Annualized Volatility (Index):** {idx_volatility:.2f}%")
                st.markdown(f"**CAGR (Index):** {idx_cagr * 100:.2f}%")
                st.markdown(f"**Sharpe Ratio (Index):** {idx_sharpe:.2f}")
                st.markdown(f"**Maximum Drawdown (Index):** {idx_drawdown:.2f}%")
            else:
                st.warning("No index data available for the selected period.")


# =============================================================================
# Tab Layout: Stacked Bar Chart, Ranked View, Market Preview
# =============================================================================
tab1, tab2, tab3 = st.tabs(["Stacked Bar Chart", "Ranked View", "Market Preview"])

# ----- Tab 1: Stacked Bar Chart -----
with tab1:
    st.markdown("""
        ## Recommended Portfolio Allocation (Latest)
        **Recommended Portfolio Allocation**  
        The pie chart below shows the allocation based on the most recent rebalancing event (from your selected end date).  
        This represents the portfolio on the latest rebalancing day and indicates the stocks that were chosen.
        <br><strong>Note:</strong> The model dynamically determines the optimal holding period until the next rebalancing. The recommended holding period (in days) is shown with the portfolio allocation below.
        <br><strong>Data Update Notice:</strong> The data displayed is updated only until <strong>{}</strong>. Additional data beyond this date will be added in the future.
    """.format(last_available_date), unsafe_allow_html=True)
    if selected_model in model_data_dict:
        selected_data = model_data_dict[selected_model]["selected_data"]
        last_row = selected_data.iloc[-1]
        st.markdown(f"### Allocation on {last_row['date']} 😊")
        st.markdown(f"**Selected Model:** {selected_model}")
        st.markdown("""
            This allocation is based on the most recent rebalancing event from your selected period. 
            It shows how the model rebalanced the portfolio on that day and the recommended holding period until the next rebalancing.
        """, unsafe_allow_html=True)
        raw_ratio = last_row["portfolio_ratio"]
        portfolio_ratio = eval(raw_ratio) if isinstance(raw_ratio, str) else raw_ratio
        top_5_portfolio = last_row["top_5_portfolio"].split(", ")
        others_value = portfolio_ratio.get("others", 1 - sum(portfolio_ratio["top_5"]))
        labels = top_5_portfolio + ["Others"]
        values = portfolio_ratio["top_5"] + [others_value]
        holding_period = last_row["pred_len"]
        pie_fig = go.Figure(data=[go.Pie(labels=labels, values=values)])
        pie_fig.update_layout(
            title=f"Next Rebalancing Recommendation: Hold this portfolio for {holding_period} days",
            template="plotly_white",
            height=400
        )
        st.plotly_chart(pie_fig, use_container_width=True)
    else:
        st.warning("No data available for the selected model and period.")

    st.markdown("""
        ## Portfolio Value & Market Index Comparison
        **Portfolio Value:**  
        The line chart below shows the cumulative return of the portfolio over the selected test period (normalized to 1 at the start).
        <br>
        **Market Index:**  
        The market index is shown as cumulative returns over the selected period (normalized to 1 at the start) for an apples‑to‑apples comparison.
    """, unsafe_allow_html=True)
    if selected_model in model_data_dict:
        selected_data = model_data_dict[selected_model]["selected_data"].sort_values("date")
        fig = go.Figure()
        # Normalize portfolio based on the first value of the selected period
        portfolio_normalized = selected_data['Final Portfolio Value'] / selected_data['Final Portfolio Value'].iloc[0]
        fig.add_trace(go.Scatter(
            x=selected_data['date'],
            y=portfolio_normalized,
            mode='lines',
            name='Portfolio (Normalized)'
        ))
        if not index_data.empty:
            filtered_index = index_data[
                (index_data["market"].str.lower() == selected_market.lower()) &
                (index_data["date"] >= pd.to_datetime(start_date)) &
                (index_data["date"] <= pd.to_datetime(end_date))
                ].sort_values("date")
            if not filtered_index.empty:
                index_normalized = filtered_index['close'] / filtered_index['close'].iloc[0]
                fig.add_trace(go.Scatter(
                    x=filtered_index["date"],
                    y=index_normalized,
                    mode='lines',
                    name=f'{selected_market.upper()} Index (Normalized)'
                ))
            else:
                st.warning("No index data available for the selected market in the chosen period.")
        else:
            st.warning("Index data is not available.")
        fig.update_layout(
            title="Portfolio vs. Market Index (Normalized)",
            xaxis_title="Date",
            yaxis_title="Cumulative Return (Starting at 1)",
            template="plotly_white"
        )
        st.plotly_chart(fig, use_container_width=True)

        # Display Performance Summary below the chart
        display_summary()
    else:
        st.warning("No data available for the selected model.")

    st.markdown("""
           ## Adaptive Rebalancing Results
           **Adaptive Rebalancing Results:**  
           The stacked bar charts below display, in chronological order, the portfolio allocation for the Top 5 stocks at each rebalancing event.
           <br>
           👉 <strong>Navigation:</strong> If the dataset is extensive, only up to 3 charts are shown per page. Use the page selector to view additional rebalancing events.
           <br>💼 This visualization shows when the model rebalanced and how the Top 5 stock ratios evolved.
       """, unsafe_allow_html=True)
    if selected_model in model_data_dict:
        stacked_bar_data = []
        for _, row in model_data_dict[selected_model]["selected_data"].iterrows():
            raw_ratio = row["portfolio_ratio"]
            portfolio_ratios = eval(raw_ratio) if isinstance(raw_ratio, str) else raw_ratio
            top_5_stocks = row["top_5_portfolio"].split(", ")
            if len(portfolio_ratios.get("top_5", [])) == len(top_5_stocks):
                rebal_date = pd.to_datetime(row["date"])
                stacked_bar_data.append({
                    "date": rebal_date,
                    "stocks": top_5_stocks,
                    "ratios": portfolio_ratios["top_5"]
                })
        if stacked_bar_data:
            group_size = 20
            groups = [stacked_bar_data[i:i + group_size] for i in range(0, len(stacked_bar_data), group_size)]
            page_size = 3
            total_pages = math.ceil(len(groups) / page_size)
            if total_pages > 1:
                page = st.number_input(f"Select page (1-{total_pages})", min_value=1, max_value=total_pages, value=1,
                                       step=1, key="rebal_page")
            else:
                page = 1
            current_groups = groups[(page - 1) * page_size: page * page_size]
            for idx, group in enumerate(current_groups, start=1):
                fig = go.Figure()
                for bar_data in group:
                    for i, stock in enumerate(bar_data["stocks"]):
                        fig.add_trace(go.Bar(
                            x=[bar_data["date"]],
                            y=[bar_data["ratios"][i]],
                            name=stock,
                            hoverinfo="name+y+x"
                        ))
                fig.update_layout(
                    barmode="stack",
                    title=f"Adaptive Rebalancing Allocation Chart {((page - 1) * page_size + idx)} of {len(groups)}",
                    xaxis_title="Rebalancing Date (Investment Time)",
                    yaxis_title="Investment Ratio of Top 5 Stocks",
                    xaxis=dict(type="date", tickformat="%Y-%m-%d"),
                    yaxis=dict(range=[0, 1]),
                    template="plotly_white"
                )
                st.plotly_chart(fig, use_container_width=True)

            # Rebalancing Timeline: Filter rebalancing events in the last 6 months of the selected period
            rebal_dates = sorted([bar_data["date"] for bar_data in stacked_bar_data])
            selected_end = pd.to_datetime(end_date)
            six_months_ago = selected_end - pd.DateOffset(months=6)
            filtered_rebal_dates = [d for d in rebal_dates if d >= six_months_ago and d <= selected_end]
            if filtered_rebal_dates:
                timeline_fig = go.Figure(data=go.Scatter(
                    x=filtered_rebal_dates,
                    y=[1] * len(filtered_rebal_dates),
                    mode='markers+lines',
                    marker=dict(size=10, color='red'),
                    line=dict(color='red', dash='dot'),
                    name='Rebalancing Dates'
                ))
                timeline_fig.update_layout(
                    title="Rebalancing Timeline (Last 6 Months of Selected Period) 📅⏰<br>Each marker represents a rebalancing event.",
                    xaxis_title="Rebalancing Date",
                    yaxis_title="",
                    yaxis=dict(showticklabels=False),
                    template="plotly_white"
                )
                st.plotly_chart(timeline_fig, use_container_width=True)
            else:
                st.warning("No rebalancing events found in the last 6 months of the selected period.")

            st.markdown("### Aggregated Insights")
            if not model_data_dict[selected_model]["selected_data"].empty:
                insight_data = model_data_dict[selected_model]["selected_data"]
                total_events = len(insight_data)
                avg_holding = insight_data["pred_len"].mean()
                rebal_period_counts = Counter(insight_data["pred_len"])
                most_common_period, period_freq = rebal_period_counts.most_common(1)[0]

                st.markdown(f"**Total Rebalancing Events:** {total_events}")
                st.markdown(f"**Average Holding Period:** {avg_holding:.2f} days")
                st.markdown(
                    f"**Most Frequently Selected Rebalancing Period:** {most_common_period} days (occurred {period_freq} times)")

                hist_fig = px.histogram(insight_data, x="pred_len", nbins=10, title="Distribution of Holding Periods")
                st.plotly_chart(hist_fig, use_container_width=True)

                all_top5 = []
                for _, row in insight_data.iterrows():
                    top5 = row["top_5_portfolio"].split(", ")
                    all_top5.extend(top5)
                stock_counts = Counter(all_top5)
                top5_common = stock_counts.most_common(5)
                top5_df = pd.DataFrame(top5_common, columns=["Stock", "Frequency"])
                st.markdown("**Top 5 Most Frequently Selected Stocks:**")
                st.table(top5_df)
                st.bar_chart(top5_df.set_index("Stock"))
            else:
                st.warning("No data available to compute aggregated insights.")
        else:
            st.warning("No adaptive rebalancing data available in the selected period.")
    else:
        st.warning("No data available for the selected model.")

# ----- Tab 2: Ranked View -----
with tab2:
    st.markdown("### Detailed Investment Recommendation (Ranked View)")
    st.markdown("""
        **Detailed Investment Recommendation**  
        The table and corresponding bar chart below provide a comprehensive breakdown of asset allocations at the most recent rebalancing event.
        This view displays the investment weight for every asset in the portfolio. 🔍📊
    """)
    if selected_model in model_data_dict:
        selected_data = model_data_dict[selected_model]["selected_data"]
        last_row = selected_data.iloc[-1]
        st.header(f"Detailed Recommendation on {last_row['date']} (Model: {selected_model})")
        raw_ratio = last_row["portfolio_ratio"]
        portfolio_ratio = eval(raw_ratio) if isinstance(raw_ratio, str) else raw_ratio
        all_portfolio = portfolio_ratio.get("all", {})
        if all_portfolio:
            allocation_summary_df = pd.DataFrame(list(all_portfolio.items()), columns=["Stock", "Contribution"])
            st.table(allocation_summary_df)
            st.bar_chart(allocation_summary_df.set_index("Stock"))
        else:
            st.warning("No detailed investment data available.")
    else:
        st.warning("No ranked view data available for the selected model.")

# ----- Tab 3: Market Preview -----
with tab3:
    st.markdown("### Market Dashboard")
    st.markdown("""
        **Market Dashboard**  
        Explore historical and current market data for selected tickers. Use the control panel to choose assets, review their price trends, and download the data as CSV.
    """)
    selected_future_data = future_prices[future_prices["market"] == selected_market].copy()
    selected_future_data["date"] = pd.to_datetime(selected_future_data["date"])
    available_tickers = selected_future_data["ticker"].unique()
    default_ticker = "GS" if "GS" in available_tickers else available_tickers[0]
    selected_tickers = st.multiselect(
        "Select Tickers for Future Price Analysis:",
        available_tickers,
        default=default_ticker
    )
    cols = st.columns(2)
    for i, ticker in enumerate(selected_tickers):
        ticker_prices = selected_future_data[selected_future_data["ticker"] == ticker].copy()
        ticker_prices = ticker_prices.drop_duplicates().sort_values(by="date")
        fig = go.Figure()
        if not ticker_prices.empty:
            fig.add_trace(go.Scatter(
                x=ticker_prices["date"],
                y=ticker_prices["close"],
                mode='lines',
                name=f"Past Prices ({ticker})",
                line=dict(color='green')
            ))
        fig.update_layout(
            title=f"Price Analysis for {ticker}",
            xaxis_title="Date",
            yaxis_title="Price",
            xaxis=dict(type="date"),
            template="plotly_white",
            height=400
        )
        cols[i % 2].plotly_chart(fig, use_container_width=True)

    st.markdown("#### Download Market Data as CSV")
    csv_data = marketdata.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="Download CSV",
        data=csv_data,
        file_name="market_data.csv",
        mime="text/csv"
    )


    def format_volume(volume):
        if volume >= 1_000_000_000:
            return f"{volume / 1_000_000_000:.2f}B"
        elif volume >= 1_000_000:
            return f"{volume / 1_000_000:.2f}M"
        return f"{volume:,}"


    selected_market = st.selectbox("Select Market for ticker prices:", marketdata["market"].unique(), index=0)
    marketdata["market"] = marketdata["market"].str.upper().str.strip()
    selected_market = selected_market.upper().strip()
    filtered_marketdata = marketdata[marketdata["market"] == selected_market]
    if filtered_marketdata.empty:
        st.warning("No data available for the selected market.")
    else:
        display_data = filtered_marketdata[
            ["ticker", "open", "close", "high", "low", "adjclose", "volume", "zadjcp"]]
        display_data = display_data.rename(columns={
            "ticker": "Ticker",
            "open": "Open",
            "close": "Close",
            "high": "High",
            "low": "Low",
            "adjclose": "Adj Close",
            "volume": "Volume",
            "zadjcp": "Zadjcp"
        })
        display_data.index = range(1, len(display_data) + 1)
        st.table(display_data)
