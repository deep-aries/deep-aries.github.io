import random
import os
import time
import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st
import yfinance as yf
from matplotlib.dates import DateFormatter, date2num, num2date
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta

from oauth2client.service_account import ServiceAccountCredentials
import gspread

# Set up API authentication
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("credentials/deep_chronos_google_api.json", scope)
client = gspread.authorize(creds)

# print("current directory",os.getcwd())

URL = "https://docs.google.com/spreadsheets/d/1bRkd6crVHwwZes4bGBT1CzxOVGBo9C38g9aOwiZM5mE/edit?gid=0#gid=0"

spreadsheet = client.open_by_url(URL)
worksheets = {
    "result": spreadsheet.worksheet("result"),
    "market": spreadsheet.worksheet("market"),
    "future": spreadsheet.worksheet("future"),
    "test": spreadsheet.worksheet("test"),
}

if "last_fetched_data" not in st.session_state:
    st.session_state.last_fetched_data = {ws: None for ws in worksheets}
if "last_update_time" not in st.session_state:
    st.session_state.last_update_time = time.time()

AUTO_REFRESH_INTERVAL = 3600

def fetch_data():
    try:
        updated_data = {}
        for name, sheet in worksheets.items():
            current_data = sheet.get_all_records()

            if current_data != st.session_state.last_fetched_data.get(name):
                updated_data[name] = current_data
                st.session_state.last_fetched_data[name] = current_data

        if updated_data:
            st.session_state.last_update_time = time.time()

        return st.session_state.last_fetched_data

    except Exception as e:
        st.error(f"Error fetching data: {e}")
        return st.session_state.last_fetched_data

current_time = time.time()
if current_time - st.session_state.last_update_time > AUTO_REFRESH_INTERVAL:
    st.session_state.last_fetched_data = {ws: None for ws in worksheets}  # 데이터 리셋
    st.session_state.last_update_time = current_time
    st.rerun()

data = fetch_data()
result_data = data["result"]  
market_data = data["market"]  
future_data = data["future"]  
test_data = data["test"]

st.set_page_config(page_title="DeepChronos", layout="wide")



st.markdown("""
    <h1>DeepChronos: Forecast-Driven Dynamic Investment Timing for Portfolio Optimization</h1>
    <hr>
    <h2>Jinkyu Kim, Hyungjung Yi, Mogan Gim, Donghee Choi, Jaewoo Kang</h2>
    <h4>no100kill@korea.ac.kr, donghee.choi@imperial.ac.uk</h4>
    <h4>KDD 2025 Submission</h4>
    </div>
""", unsafe_allow_html=True)


# Title
st.title("Portfolio Allocation Over Time (Stacked Bar Chart)")
# csv_path = "fakedata/fakeresult.csv" 
# data = pd.read_csv(csv_path)
# market_path="fakedata/fakemarketdata.csv"
# marketdata=pd.read_csv(market_path)
# marketdata["date"]= pd.to_datetime(marketdata["date"])
# future_prices_path = 'fakedata/fakefuturedata.csv'
# future_prices = pd.read_csv(future_prices_path)

market_df = pd.DataFrame(market_data)
market_df["date"] = pd.to_datetime(market_df["date"])

result_df = pd.DataFrame(result_data)
result_df["date"] = pd.to_datetime(result_df["date"])

future_df = pd.DataFrame(future_data)
future_df.set_index('Ticker', inplace=True)
current_date = datetime(2025, 1, 23)

# Stocks List (Example)
stocks = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA", "META", "NVDA", "NFLX", "INTC", "AMD"]
models=["LSTM","TCN","lightGBM","arima","fedformer","transformer","deformableTST","crossformer","coformer","autoformer","informer"]
col1, col2 = st.columns(2)

# Left column (col1)
with col1:
    selected_len = st.multiselect("Select Hold Duration", ["static 1", "static 5", "static 20","dynamic(ours)"], default="dynamic(ours)")
    selected_model = st.multiselect("Select Model", models, default=models[:3])


# Right column (col2)
with col2:
    selected_market = st.multiselect("Select Market", ["NASDAQ","KOSPI","CSI300","DJWNS"], default="NASDAQ")
    selected_data = st.multiselect("Select Data Type", ["general","alpha158"], default="general")
    start_date = st.date_input("Test Data: Start Date", value=pd.Timestamp("2025-01-26"))

    end_date = st.date_input("Test Data: End Date", value=pd.Timestamp.today())

# Tabs for different views
tab1, tab2, tab3, tab4 = st.tabs(["Stacked Bar Chart", "Ranked View","Market Preview", "test"])
with tab1:

    # 원형 그래프 생성
    st.subheader("Recommended Portfolio Allocation on 2025-01-26")

    # 첫 번째 행 데이터 가져오기
    first_row = result_df.iloc[0]
    top_5_portfolio = first_row["top_5_portfolio"].split(", ")  # 종목 이름
    portfolio_ratio = eval(first_row["portfolio_ratio"])       # 비율

    # Plotly Pie Chart
    pie_fig = go.Figure(data=[go.Pie(
        labels=top_5_portfolio,
        values=portfolio_ratio,
        hoverinfo='label+percent',
        textinfo='label+value',
        marker=dict(
            line=dict(color='black', width=1)  # 테두리 추가
        )
    )])

    # Layout 설정
    pie_fig.update_layout(
        title="Hold this ratio for (20) days - 3rd day",
        template="plotly_white",
        height=400
    )

    # Streamlit에 원형 그래프 표시
    st.plotly_chart(pie_fig, use_container_width=True)


    # Select model(s)
    models = result_df['model'].unique()
    selected_models = st.multiselect("Select Models:", models, default=models[:3])

    # Filter data based on selected models
    filtered_df = result_df[result_df['model'].isin(selected_models)].copy()

    # Identify points where Final Portfolio Value changes
    # Identify points where pred_len ends or changes
    filtered_df['shifted_pred_len'] = filtered_df['pred_len'].shift(-1)  # 다음 pred_len 값
    filtered_df['remaining_days'] = filtered_df['pred_len'].cumsum() - filtered_df.index.to_series()

    # Identify when pred_len ends or changes
    filtered_df = filtered_df[
        (filtered_df['remaining_days'] % filtered_df['pred_len'] == 0) |  # pred_len 끝나는 지점
        (filtered_df['pred_len'] != filtered_df['shifted_pred_len'])      # pred_len 값 변경 지점
    ]

    # 날짜 선택 UI 추가
    st.subheader("Highlight Specific Date")
    all_dates = sorted(result_df['date'].dt.date.unique())  # 전체 데이터에서 유효한 날짜 리스트
    selected_date = st.selectbox("Select a date to highlight:", options=all_dates)

    # highlight_date를 선택된 날짜 또는 이전의 가장 가까운 날짜로 설정
    available_dates = filtered_df['date'].dt.date.unique()
    if selected_date in available_dates:
        highlight_date = selected_date
    else:
        highlight_date = max([d for d in available_dates if d <= selected_date], default=min(available_dates))

    # Plotting the graph using Plotly
    fig = go.Figure()

    
    for model in selected_models:
        model_df = filtered_df[filtered_df['model'] == model]
        color = f"rgba({hash(model) % 255}, {(hash(model) // 255) % 255}, {(hash(model) // (255*255)) % 255}, 1)"

        # Add the line trace (this will be included in the legend)
        fig.add_trace(go.Scatter(
            x=model_df['date'],
            y=model_df['Final Portfolio Value'],
            mode='lines',
            name=model,
            line=dict(width=3, color=color),
            marker=dict(size=8, color=color),
            showlegend=True
        ))
        max_value = model_df['Final Portfolio Value'].max()
        min_value = model_df['Final Portfolio Value'].min()
        # Highlight selected or nearest previous date on the line graph
        if highlight_date in model_df['date'].dt.date.values:
            highlighted_value = model_df[model_df['date'].dt.date == highlight_date]['Final Portfolio Value'].values[0]
            # 빨간색 세로선 추가
            fig.add_shape(
                type="line",
                x0=highlight_date,  # 세로선의 시작 x축 값
                x1=highlight_date,  # 세로선의 끝 x축 값
                y0=min_value * 0.95,  # y축의 시작 값 (그래프의 최하단 값으로 설정)
                y1=max_value,
                line=dict(
                    color="red",
                    width=5,
                    dash='dashdot'
                ),
            )

    fig.update_layout(
        title="Predicted Final Portfolio Value by Model",
        xaxis_title="Date",
        yaxis_title="Final Portfolio Value",
        legend_title="Models",
        template="plotly_white",
    )
    st.plotly_chart(fig)

    # Add stacked bar charts below the main graph
st.subheader("Test date results by model")

for model in selected_models:
    model_df = filtered_df[filtered_df['model'] == model]

    stacked_bar_data = []
    for _, row in model_df.iterrows():
        portfolio_ratios = eval(row['portfolio_ratio']) if isinstance(row['portfolio_ratio'], str) else []
        top_5_stocks = row['top_5_portfolio'].split(', ') if isinstance(row['top_5_portfolio'], str) else []
        if len(portfolio_ratios) == len(top_5_stocks):
            stacked_bar_data.append({
                'date': row['date'],
                'stocks': top_5_stocks,
                'ratios': portfolio_ratios
            })

    if stacked_bar_data:
        fig = go.Figure()

        # highlight_date를 선택된 날짜 또는 이전의 가장 가까운 날짜로 설정
        available_dates = [bar['date'].date() for bar in stacked_bar_data]
        if selected_date in available_dates:
            highlight_date = selected_date
        else:
            highlight_date = max([d for d in available_dates if d <= selected_date], default=min(available_dates))

        for bar_data in stacked_bar_data:
            # 각 stock의 색상 설정
            stock_colors = px.colors.qualitative.Plotly[:len(bar_data['stocks'])]
            for i, stock in enumerate(bar_data['stocks']):
                # highlight_date와 일치하는 날짜는 원래 색상, 나머지는 투명하게 처리
                if bar_data['date'].date() == highlight_date:
                    opacity = 1.0  # 강조된 날짜는 불투명
                else:
                    opacity = 0.2  # 나머지 날짜는 흐리게

                fig.add_trace(go.Bar(
                    x=[bar_data['date']],
                    y=[bar_data['ratios'][i]],
                    name=stock,
                    marker=dict(color=stock_colors[i], opacity=opacity),
                    hoverinfo='text',
                    text=stock
                ))

        fig.update_layout(
            barmode='stack',
            title=f"Stacked Portfolio Ratios for {model}",
            xaxis_title="Date",
            yaxis_title="Portfolio Ratio",
            template="plotly_white",
            height=400,
            margin=dict(l=20, r=20, t=30, b=20)
        )

        st.subheader(f"{model}")
        st.plotly_chart(fig, use_container_width=True)


with tab2:
    st.header("Recommendation of Portfolio Contributions by End Date")

    # Summarize total contributions by stock
    portfolio_allocation_summary = []

    # Extract the top 5 portfolio ratios per row and aggregate contributions
    for _, row in result_df.iterrows():
        top_5_ratios = row["portfolio_ratio"]
        if isinstance(top_5_ratios, str):
            try:
                top_5_ratios = eval(top_5_ratios)
            except:
                continue
        top_5_stocks = row["top_5_portfolio"].split(", ") if isinstance(row["top_5_portfolio"], str) else []
        if len(top_5_ratios) == len(top_5_stocks):
            for stock, contribution in zip(top_5_stocks, top_5_ratios):
                portfolio_allocation_summary.append({"Stock": stock, "Contribution": contribution})

    # Convert to DataFrame
    allocation_summary_df = pd.DataFrame(portfolio_allocation_summary)

    # Aggregate total contributions per stock
    total_contributions = allocation_summary_df.groupby("Stock")["Contribution"].sum().sort_values(ascending=False)

    # Create a recommendation DataFrame
    rec_df = pd.DataFrame({
        "Stock": total_contributions.index,
        "Total Contribution": total_contributions.values
    })

    # Display Recommendation table
    st.write("Portfolio Contributions Recommendation by Total Value:")
    st.table(rec_df)

    # Bar chart for Recommendation contributions
    st.bar_chart(total_contributions)

with tab3:
    st.header("Market Dashboard")


    # Allow user to select tickers
    selected_tickers = st.multiselect("Select Tickers for Future Price Analysis:", future_df.index, default=future_df.index[:3])

    # Plot prices for selected tickers
    cols = st.columns(2)
    for i, ticker in enumerate(selected_tickers):
        ticker_prices = future_df.loc[ticker]

        # Split data into past and future prices based on the current date
        past_prices = ticker_prices[ticker_prices.index < current_date.strftime('%Y-%m-%d')]
        future_prices_data = ticker_prices[ticker_prices.index >= current_date.strftime('%Y-%m-%d')]

        # Create figure
        fig = go.Figure()

        # Add past prices trace (green)
        fig.add_trace(go.Scatter(
            x=past_prices.index,
            y=past_prices.values,
            mode='lines+markers',
            name=f"Past Prices ({ticker})",
            line=dict(color='green')
        ))

        # Add future prices trace (blue, including current date)
        fig.add_trace(go.Scatter(
            x=future_prices_data.index,
            y=future_prices_data.values,
            mode='lines+markers',
            name=f"Future Prices ({ticker})",
            line=dict(color='blue')
        ))
        if not past_prices.empty and not future_prices_data.empty:
            fig.add_trace(go.Scatter(
                x=[past_prices.index[-1], future_prices_data.index[0]],
                y=[past_prices.values[-1], future_prices_data.values[0]],
                mode='lines',
                line=dict(color='blue'),
                showlegend=False
            ))

        # Update layout
        fig.update_layout(
            title=f"Price Analysis for {ticker}",
            xaxis_title="Date",
            yaxis_title="Price",
            template="plotly_white",
            height=400
        )

        # Render the figure
        cols[i % 2].plotly_chart(fig, use_container_width=True)

    # Convert 'volume' to a readable format (e.g., millions or billions)
    def format_volume(volume):
        if volume >= 1_000_000_000:
            return f"{volume / 1_000_000_000:.2f}B"
        elif volume >= 1_000_000:
            return f"{volume / 1_000_000:.2f}M"
        return f"{volume:,}"

    # Add formatted columns for display
    market_df["Formatted Volume"] = market_df["volume"].apply(format_volume)
    market_df["Price Change (1D%)"] = market_df["zadjcp"].apply(lambda x: f"{x * 100:.2f}%")
    market_df["Formatted Price"] = market_df["close"].apply(lambda x: f"${x:,.2f}")

    # Create a styled DataFrame for display
    display_df = market_df[["ticker", "Formatted Price", "Price Change (1D%)", "volume", "Formatted Volume"]]
    display_df = display_df.rename(columns={
        "ticker": "Ticker",
        "Formatted Price": "Price",
        "Price Change (1D%)": "1D Change",
        "Formatted Volume": "Volume (24h)"
    })

    # Render the table in Streamlit
    st.table(display_df)


with tab4:
    if st.button("Force Refresh"):
        st.session_state.last_fetched_data = {ws: None for ws in worksheets}  # 데이터 리셋
        st.session_state.last_update_time = time.time()
        st.rerun()

    st.dataframe(test_data)
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        value1 = st.number_input("Number", value=10)
    with col2:
        value2 = st.text_input("Text", value="test")
    with col3:
        value3 = st.number_input("Float", value=0.33322)
    with col4:
        value4 = st.date_input("Date")

    if st.button("Submit"):
        worksheets['test'].append_row([value1, value2, value3, str(value4)])
        st.success("Data added to Google Sheets!")